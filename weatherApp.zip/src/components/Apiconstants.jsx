export const API_KEY = "ffee86a848ed91a20d86ac6ea1aa1e31";
export const BASE_URL = `https://api.openweathermap.org/data/2.5/weather?appid=${API_KEY}`;
